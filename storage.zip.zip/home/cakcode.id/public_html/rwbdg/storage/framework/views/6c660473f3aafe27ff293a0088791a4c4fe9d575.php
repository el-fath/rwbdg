<?php $__env->startSection('content'); ?>
<!--About Us -->
<section id="about" class="padding_bottom">
    
  <section class="page-banner padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <h1 class="text-uppercase"><?php echo app('translator')->getFromJson('specialist.find_special'); ?></h1>
          
        </div>
      </div>
    </div>
  </section>
  <section id="agent-2" class="padding_top padding_bottom_half">
    <div class="container">
      <div class="row">

        <?php $__currentLoopData = $data['Marketing']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-4 bottom40">
          <div class="agent_wrap">
            <div class="image">
              <img src="<?php echo e($val->ImagePathSmall); ?>" style="width: 364px; height:388px;object-fit: contain;" alt="<?php echo e($val->name); ?>">
              <div class="img-info" style="width: 364px; height:388px;">
                <h3><?php echo e($val->name); ?></h3>
                <span><?php echo e($val->level['title']); ?></span>
                <p class="top20 bottom30"><?php echo e($val->description); ?></p>
                <table class="agent_contact table">
                  <tbody>
                    <tr class="bottom10">
                      <td><strong><?php echo app('translator')->getFromJson('specialist.phone'); ?>:</strong></td>
                      <td class="text-right"><?php echo e($val->phone); ?></td>
                    </tr>
                    <tr>
                      <td><strong><?php echo app('translator')->getFromJson('specialist.email'); ?>:</strong></td>
                      <td class="text-right"><a href="#."><?php echo e($val->email); ?></a></td>
                    </tr>
                  </tbody>
                </table>
                <hr>
                <a class="btn-more" href="<?php echo e(route('specialist.id', $val->slug)); ?>">
                <i><img alt="arrow" src="<?php echo e(url('public/assets/user')); ?>/images/arrow-yellow.png"></i><span><?php echo app('translator')->getFromJson('specialist.profile'); ?></span><i><img alt="arrow" src="<?php echo e(url('public/assets/user')); ?>/images/arrow-yellow.png"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      <?php echo e($data['Marketing']->links("user/include/pagination")); ?>

    </div>
  </section>
  <!-- Agent End -->
  
  
</section>
  
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('user/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/specialist/specialist.blade.php ENDPATH**/ ?>