<h2 class="text-uppercase bottom20"><?php echo app('translator')->getFromJson('property.contact_agent'); ?></h2>
<div class="row">
    <div class="col-sm-6 bottom40">
        <div class="agent_wrap">
            <div class="image">
                <img src="<?php echo e($marketing->ImagePathSmall); ?>" alt="<?php echo e($marketing->name); ?>">
            </div>
        </div>
    </div>
    <div class="col-sm-6 bottom40">
        <div class="agent_wrap">
            <h3><?php echo e($marketing->name); ?></h3>
            <p class="bottom30"><?php echo e($marketing->description); ?></p>
            <table class="agent_contact table">
                <tbody>
                    <tr class="bottom10">
                        <td><strong>Phone:</strong></td>
                        <td class="text-right"><?php echo e($marketing->phone); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Email Adress:</strong></td>
                        <td class="text-right"><a href="#"><?php echo e($marketing->email); ?></a></td>
                    </tr>
                    <tr>
                        <td><strong>Facebook:</strong></td>
                        <td class="text-right"><a href="#"><?php echo e($marketing->facebook); ?></a></td>
                    </tr>
                    <tr>
                        <td><strong>Instagram:</strong></td>
                        <td class="text-right"><a href="#"><?php echo e($marketing->instagram); ?></a></td>
                    </tr>
                </tbody>
            </table>
            <div style="border-bottom:1px solid #d3d8dd;" class="bottom15"></div>
            <ul class="social_share">
                <li><a href="javascript:void(0)" class="google"><i class="icon-google4"></i></a></li>
                <li><a href="https://www.facebook.com/<?php echo e($marketing->facebook); ?>" target="_blank"
                        title="https://www.facebook.com/<?php echo e($marketing->facebook); ?>" class="facebook">
                        <i class="icon-facebook-1"></i></a>
                </li>
                <li><a href="https://www.instagram.com/<?php echo e($marketing->instagram); ?>" target="_blank"
                        title="https://www.instagram.com/<?php echo e($marketing->instagram); ?>" class="google">
                        <i class="icon-instagram"></i></a>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/include/marketing_profile.blade.php ENDPATH**/ ?>