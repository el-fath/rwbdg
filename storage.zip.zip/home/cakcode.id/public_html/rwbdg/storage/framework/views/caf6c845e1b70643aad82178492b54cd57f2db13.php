<?php echo $__env->make('user/include/slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('user/include/search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<!-- News Start -->
<section id="news-section-1" class="property-details padding_top">
    <div class="container property-details">
       <div class="row">
          <div class="col-md-8">
             <div class="row">
                <?php $__currentLoopData = $data['news_latest']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo $__env->make('user/items/thumb_news_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
             <div class="row margin_bottom">
                  <div class="col-sm-12 text-center top20">
                     <a href="<?php echo e(route("news")); ?>" class="btn-dark border_radius uppercase margin40"><?php echo app('translator')->getFromJson("global.more_news_btn"); ?></a>
                  </div>
             </div>
          </div>
          <aside class="col-md-4 col-xs-12">
             <div class="row">
                <div class="col-md-12">
                   <form class="form-search bottom40" method="get" id="news-search" action="<?php echo e(route("news")); ?>">
                      <div class="input-append">
                         <input type="text" class="input-medium search-query" placeholder="Search Here" name="search" value="">
                         <button type="submit" class="add-on"><i class="icon-icons185"></i></button>
                      </div>
                   </form>
                </div>
                <div class="col-md-12">
                   <h3 class="bottom20"><?php echo app('translator')->getFromJson('home.categories_label'); ?></h3>
                   <ul class="pro-list bottom20">
                     <?php $__currentLoopData = $data['news_category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <li>
                           <a href="<?php echo e(route('news', ['category'=>$item->id])); ?>">  <?php echo e($item->title); ?></a>
                        </li>
                        
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                   </ul>
                </div>
             </div>
             <div class="row">
                <div class="col-md-12">
                   <h3 class="bottom40 margin40"><?php echo app('translator')->getFromJson('home.latest_property_label'); ?></h3>
                </div>
             </div>
             <?php $__currentLoopData = $data['property_latest']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('user/items/thumb_property_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <div class="row">
                <div class="col-md-12">
                   <h3 class="margin40 bottom20"><?php echo app('translator')->getFromJson('home.featured_property_label'); ?></h3>
                </div>
                <div class="col-md-12 padding-t-30">
                   <div id="agent-2-slider" class="owl-carousel">
                      <?php $__currentLoopData = $data['property_featured']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo $__env->make('user/items/thumb_property_side_slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
                </div>
             </div>
          </aside>
       </div>
    </div>
 </section>
 <!-- News End -->

<!--Parallax-->
<section id="parallax_four" class="padding">
  <div class="container">
    <div class="row">
      <div class="col-sm-8 bottom30">
        <h2><?php echo app('translator')->getFromJson('home.home1_label'); ?></h2>
        <h4 class="top20"><?php echo app('translator')->getFromJson('home.home1_desc_label'); ?></h4>
      </div>
    </div>
  </div>
</section>
<!--About Owner ends-->
<!--Agents-->
<section id="layouts" class="padding_top">
   
  <div class="container">
    <div class="row">
      <h2><?php echo app('translator')->getFromJson('home.markerplace_title_label'); ?></h2> 
      <hr>
      <?php $__currentLoopData = $data['marketplaces']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm-4 margin_bottom">
      <div class="media news_media">
            <div class="media-left">
               <img class="media-object border_radius" style="width: 100px;" src="<?php echo e($item->ImagePathSmall); ?>" alt="<?php echo e($item->title); ?>">
            </div>
            <div class="media-body" style="vertical-align: middle;">
                  <h2 class="uppercase"><?php echo e($item->title); ?></h2>
            </div>
      </div>
     
        <p class="heading_space"></p>
        <?php $__currentLoopData = $item->properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="media news_media">
            <div class="media-left">
              <a target="_blank" href="<?php echo e($prop->url); ?>">
              <img class="media-object border_radius" style="width: 120px;height: 80px;" src="<?php echo e($prop->property->ImagePathSmall); ?>" alt="Latest news">
              </a>
            </div>
            <div class="media-body" style="vertical-align: middle;">
              <h3><a target="_blank" href="<?php echo e($prop->url); ?>"><?php echo e($prop->property->title); ?></a></h3>

              <?php if($prop->property->type_transaction == 'sale'): ?>
                  <span class=""><i class="icon-dollar"></i>Rp. <?php echo e(number_format($prop->property->sale_price,0,",",".")); ?></span>
              <?php else: ?>
                  <span class=""><i class="icon-dollar"></i>Rp. <?php echo e(number_format($prop->property->rent_price,0,",",".")); ?></span>
              <?php endif; ?>
              <p class=""><?php echo $prop->property->address; ?>, <?php echo $prop->property->Location; ?>

              </p>
            </div>
         </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div style="border-bottom:1px solid #d3d8dd;"></div>
  </div>
</section>
<!--Agents Ends-->

<!--Types-->
<section id="types" class="padding">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 text-center">
        <h2 class="uppercase"><?php echo app('translator')->getFromJson('global.property_category_label'); ?></h2>
        <p class="heading_space"><?php echo app('translator')->getFromJson('global.property_category_desc'); ?></p>
      </div>
    </div>
    <div id="" class="padding row">
        <?php $__currentLoopData = $data['property_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-4">
            <?php echo $__env->make('user/items/thumb_category_property_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<!--Types Ends-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/home.blade.php ENDPATH**/ ?>