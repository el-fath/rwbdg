<?php $__env->startSection('slider'); ?>
<!--Slider-->
  <div class="rev_slider_wrapper">
    <div id="rev_overlaped" class="rev_slider"  data-version="5.0">
      <ul>
        <!-- SLIDE -->
        <?php $__currentLoopData = $data['slide']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li data-transition="fade">
            <img src="<?php echo e($item->ImagePath); ?>" alt="" data-bgposition="center center" data-bgfit="cover" class="rev-slidebg">		
            <div class="tp-caption tp-static-layer" 
              id="slide-37-layer-2" 
              data-x="['left','left','left','left']" data-hoffset="['50','50','50','50']" 
              data-y="['bottom','bottom','bottom','bottom']" data-voffset="['230','180','150','100']"  
              data-whitespace="nowrap"
              data-visibility="['on','on','on','on']"
              data-fontsize="['48','48','28','28']"
              data-start="500" 
              data-responsive_offset="on"
              data-basealign="slide" 
              data-startslide="0" 
              data-endslide="5" 
              style="z-index: 5;">
              <?php
                  // dd($item);
              ?>
          <h1><span class="t_white"><?php echo e($item->title); ?></span></h1>
            </div>
            <div class="tp-caption tp-static-layer" 
              id="slide-37-layer-2" 
              data-x="['left','left','left','left']" data-hoffset="['50','50','50','50']" 
              data-y="['bottom','bottom','bottom','bottom']" data-voffset="['150','100','120','120']" 
              data-whitespace="nowrap"
              data-visibility="['on','on','on','on']"
              data-start="500" 
              data-basealign="slide" 
              data-startslide="0" 
              data-endslide="5" 
              style="z-index: 5;">
              <p class="t_white"><?php echo $item->description; ?>

              </p>
            </div>					
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
        
      </ul>
    </div>
  </div>
<!--Slider ends-->
<?php $__env->stopSection(); ?><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/include/slider.blade.php ENDPATH**/ ?>