<?php $__env->startSection('content'); ?>
<?php
$news = $data['news'];
?>
<!-- News Details Start -->
<section id="news-section-1" class="news-section-details property-details padding_top">
    <div class="container">

        <div class="row heading_space">
            <div class="row">
                <div class="news-1-box clearfix">
                    <div class="col-md-12 col-sm-12 col-xs-12 top30">
                        <h1><?php echo e($news->title); ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row">

                    <div class="news-1-box clearfix">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <img src="<?php echo e($news->ImagePath); ?>" alt="<?php echo e($news->title); ?>" class="img-responsive" />
                        </div>

                        <div class="col-md-12 col-sm-12 col-xs-12 top30">

                            <div class="news-details bottom10">
                                <span><i class="icon-icons228"></i> <?php echo e($news->created_at->format('M d,Y')); ?></span>
                            </div>

                            <?php echo $news->description; ?>


                        </div>
                    </div>

                </div>
                <div class="row heading_space">

                    <div class="news-2-tag">
                        <div class="col-md-12 col-sm-12 col-xs-12 text-left">
                            <div class="social-icons">
                                <h4>Share:</h4>
                                <ul class="social_share">
                                    <li><a href="#." class="facebook"><i class="icon-facebook-1"></i></a></li>
                                    <li><a href="#." class="twitter"><i class="icon-twitter-1"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- Property Detail Start -->
                <?php if($news->property): ?>
                <div class="row clearfix">
                    <div class="col-md-12 listing1 property-details">
                        <h2>Related Property</h2>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 listing1 property-details">
                        <h2 class="text-uppercase"><?php echo e($news->property->title); ?></h2>
                        <p class="bottom30"><?php echo e($news->property->address); ?>,<?php echo e($news->property->Location); ?></p>
                        <div>
                            <img src="<?php echo e($news->property->ImagePathMedium); ?>" alt="<?php echo e($news->property->title); ?>"
                                class="img-responsive" />
                        </div>
                        <div class="property_meta bg-black bottom40">
                            <span><i class="icon-select-an-objecto-tool"></i><?php echo e($news->property->land_area); ?>

                                m<sup>2</sup></span>
                            <span><i class="icon-old-television"></i><?php echo e($news->property->building_area); ?>

                                m<sup>2</sup></span>
                            <span><i
                                    class=" icon-microphone"></i><?php echo e($news->property->bedroom); ?>+<?php echo e($news->property->extra_bedroom); ?>

                                Office Rooms</span>
                            <span><i
                                    class="icon-safety-shower"></i><?php echo e($news->property->bathroom); ?>+<?php echo e($news->property->extra_bedroom); ?>

                                Bathroom</span>
                        </div>
                        <h2 class="text-uppercase"><?php echo app('translator')->getFromJson('property.property_description_label'); ?></h2>
                        <p class="bottom30"><?php echo $news->property->description; ?></p>
                        <h2 class="text-uppercase bottom20"><?php echo app('translator')->getFromJson('property.quick_summary_label'); ?></h2>
                        <div class="row property-d-table bottom40">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <table class="table table-striped table-responsive">
                                    <tbody>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.property_id'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->id); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.price'); ?></b></td>
                                            <?php if($news->property->type_transaction == 'sale'): ?>
                                            <td class="text-right">Rp.
                                                <?php echo e(number_format($news->property->sale_price,0,",",".")); ?></td>
                                            <?php else: ?>
                                            <td class="text-right">Rp.
                                                <?php echo e(number_format($news->property->rent_price,0,",",".")); ?></td>
                                            <?php endif; ?>
                                        </tr>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.land_area'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->land_area); ?> m<sup>2</sup></td>
                                        </tr>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.building_area'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->building_area); ?> m<sup>2</sup></td>
                                        </tr>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.bedrooms'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->bedroom); ?> +
                                                <?php echo e($news->property->extra_bedroom); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.bathrooms'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->bathroom); ?> +
                                                <?php echo e($news->property->extra_bathroom); ?></td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <table class="table table-striped table-responsive">
                                    <tbody>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.type'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->type_transaction); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.available_from'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->created_at->format('M d,Y')); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.certificate'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->certificate); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.category'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->category->title); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.floors'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->floor); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b><?php echo app('translator')->getFromJson('property.summary.electricity'); ?></b></td>
                                            <td class="text-right"><?php echo e($news->property->electricity); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <h2 class="text-uppercase bottom20">Marketplace</h2>
                        <div class="row property-d-table bottom40">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php $__currentLoopData = $news->property->marketplaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="media">
                                        <div class="media-left">
                                          <a href="#">
                                            <img class="media-object" style="width: 64px;height: 64px;object-fit: cover;" src="<?php echo e($item->marketplace->ImagePathSmall); ?>" alt="<?php echo e($item->marketplace->title); ?>">
                                          </a>
                                        </div>
                                        <div class="media-body" style="vertical-align: middle;">
                                        <h4 class="media-heading"><?php echo e($item->marketplace->title); ?></h4>
                                        <a href="<?php echo e($item->url); ?>" target="_blank"><?php echo e($item->url); ?></a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <?php if($news->property->marketing): ?>
                        <?php
                        $marketing = $news->property->marketing;
                        ?>
                        <?php echo $__env->make('user/include/marketing_profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-sm-10">
                                <h2 class="text-uppercase top20"><?php echo app('translator')->getFromJson('property.similar_properties_label'); ?></h2>
                                <br>
                            </div>
                            <div class="col-sm-10">
                                <div id="two-col-slider" class="owl-carousel">
                                    <?php $__currentLoopData = $news->SimilarProperties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('user/items/thumb_property', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Property Detail End -->
                <?php endif; ?>
            </div>
            <aside class="col-md-4 col-xs-12">
                <form class="form-search" method="get" id="news-search" action="<?php echo e(route("news")); ?>">
                    <div class="input-append">
                        <input type="text" class="input-medium search-query" placeholder="Search Here" name="search" value="">
                        <button type="submit" class="add-on"><i class="icon-icons185"></i></button>
                    </div>
                </form>
                <hr>
                <h3><?php echo app('translator')->getFromJson('home.categories_label'); ?></h3>
                <ul class="pro-list padding-t-20">
                    <?php $__currentLoopData = $data['news_category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('news', ['category'=>$item->id])); ?>">  <?php echo e($item->title); ?></a>
                         </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="bottom40 margin40"><?php echo app('translator')->getFromJson('home.latest_property_label'); ?></h3>
                    </div>
                </div>
                <?php $__currentLoopData = $data['property_latest']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('user/items/thumb_property_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="margin40 bottom20"><?php echo app('translator')->getFromJson('home.featured_property_label'); ?></h3>
                    </div>
                    <div class="col-md-12">
                        <div id="agent-2-slider" class="owl-carousel">
                            <?php $__currentLoopData = $data['property_featured']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('user/items/thumb_property_side_slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </aside>
        </div>

    </div>
</section>
<!-- News Details End -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/news_detail.blade.php ENDPATH**/ ?>