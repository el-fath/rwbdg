<div class="media bottom30">
    <div class="media-body">
    <a href="<?php echo e(route('news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
        <span><i class="icon-clock5"></i><?php echo e($item->created_at->format('M d,Y')); ?></span>
    </div>
</div><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/items/thumb_news_footer.blade.php ENDPATH**/ ?>