<div class="cbp-item latest <?php echo e($item->type_transaction); ?>">
    <div class="property_item">
        <div class="image">
        <a href="<?php echo e(route('property.id', $item->slug)); ?>"><img src="<?php echo e($item->ImagePathSmall); ?>" alt="<?php echo e($item->title); ?>" class="img-responsive" style="height: 210px;"></a>
        <div class="price clearfix"> 
            <?php if($item->type_transaction == "sale"): ?>
                <span class="tag pull-right">Rp <?php echo e(number_format($item->sale_price,0,",",".")); ?></span>
            <?php else: ?>
                <span class="tag pull-right">Rp <?php echo e(number_format($item->rent_price,0,",",".")); ?></span>
            <?php endif; ?>
        </div>
        <span class="tag_t">For <?php echo e(ucfirst($item->type_transaction)); ?></span> 
        
        <?php if($item->is_featured): ?>
            <span class="tag_l">Featured</span>
        <?php endif; ?>
        
        </div>
        <div class="proerty_content">
        <div class="proerty_text">
            <h3 class="captlize"><a href="property_detail1.html"><?php echo e($item->title); ?></a></h3>
            <p><?php echo e($item->address); ?></p> <?php echo e($item->location); ?>

        </div>
        <div class="property_meta transparent"> 
            <span><i class="icon-select-an-objecto-tool"></i><?php echo e($item->land_area); ?> m<sup>2</sup> <?php echo app('translator')->getFromJson('property.thumb.land_label'); ?></span> 
            <span><i class="icon-select-an-objecto-tool"></i><?php echo e($item->building_area); ?> m<sup>2</sup> <?php echo app('translator')->getFromJson('property.thumb.building_label'); ?></span> 
            
        </div>
        <div class="property_meta transparent bottom30"> 
            <span><i class="icon-bed"></i><?php echo e($item->bedroom); ?>+<?php echo e($item->extra_bedroom); ?> <?php echo app('translator')->getFromJson('property.thumb.bedroom_label'); ?></span> 
            <span><i class="icon-safety-shower"></i><?php echo e($item->bathroom); ?>+<?php echo e($item->extra_bathroom); ?> <?php echo app('translator')->getFromJson('property.thumb.bathroom_label'); ?></span>   
            
        </div>
        <div class="favroute clearfix">
            <p><i class="icon-calendar2"></i> <?php echo e($item->created_at->diffForHumans()); ?> </p>
            <ul class="pull-right">
            
            <li><a href="#marketplace" class="share_expender" data-toggle="collapse"><i class="icon-globe"></i></a></li>
            </ul>
        </div>
        <div class="toggle_share collapse" id="marketplace">
            <ul>
                <?php $__currentLoopData = $item->marketplaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a target="_blank" href="<?php echo e($val->url); ?>" class="facebook"><i class="icon-home"></i> <?php echo e($val->marketplace->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        </div>
    </div>
    </div><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/items/thumb_property.blade.php ENDPATH**/ ?>