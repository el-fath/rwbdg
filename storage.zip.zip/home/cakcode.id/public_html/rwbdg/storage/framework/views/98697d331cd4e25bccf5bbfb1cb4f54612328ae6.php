<div class="item">
    <div class="property_item heading_space">
        <div class="image">
            <a href="<?php echo e(route('property.id', $item->slug)); ?>"><img src="<?php echo e($item->ImagePathSmall); ?>" alt="listin" class="img-responsive" style="height: 250px;"></a>
            <div class="feature"><span class="tag-2">For <?php echo e($item->type_transaction); ?></span></div>
            <div class="price clearfix"><span class="tag pull-right"><?php echo e($item->title); ?></small></span></div>
        </div>
    </div>
</div><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/items/thumb_property_side_slide.blade.php ENDPATH**/ ?>