<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<?php echo SEO::generate(); ?>

<title>Castle</title>

<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/reality-icon.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/bootsnav.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/jquery.fancybox.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/owl.transitions.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/cubeportfolio.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/settings.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/range-Slider.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/search.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/user')); ?>/css/style.css">
<link rel="icon" href="<?php echo e($config->FaviconPath); ?>">
<script src="<?php echo e(url('public/assets/user')); ?>/js/jquery-2.1.4.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.min.js"></script>
<script src="<?php echo e(url('public/assets/admin')); ?>/assets/js/plugins/loaders/blockui.min.js"></script>
<script src="<?php echo e(url('public/assets/admin')); ?>/assets/js/plugins/notifications/jgrowl.min.js"></script>
<script src="<?php echo e(url('public/assets/admin')); ?>/assets/js/demo_pages/extra_jgrowl_noty.js"></script>
<script src="<?php echo e(url('public')); ?>/js/cakcode.js"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>

<style>
  .navbar-nav {
    margin-top: 9px;
  }
  /* Always set the map height explicitly to define the size of the div
  * element that contains the map. */
  #map {
    height: 100%;
  }
  /* Optional: Makes the sample page fill the window. */
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
  }
</style>

</head>




<body>


<!--Loader-->
<div class="loader">
  <div class="span">
    <div class="location_indicator"></div>
  </div>
  <div class="span">
      <label class="label">Loading</label>
    </div>
</div>
 <!--Loader-->               

<?php echo $__env->yieldContent('slider'); ?>

<!--Header-->
<div id="mainMenuBarAnchor"></div>
<header class="white_header">
  <nav class="navbar navbar-default bootsnav">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
            <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href=""><img src="<?php echo e($config->LogoPath); ?>" style="max-height: 70px;width: 70px;" class="logo" alt=""></a>
          </div>
          <div class="collapse navbar-collapse" id="navbar-menu">
            <ul class="nav navbar-nav navbar-left" data-in="fadeIn" data-out="fadeOut" style="margin-left: 15px;">
              <li class="<?php echo e(($data['menu'] == "home") ? "active" : ""); ?>"><a href="<?php echo e(route("index")); ?>"><?php echo app('translator')->getFromJson("global.menu.home_label"); ?></a></li>
              <li class="<?php echo e(($data['menu'] == "about") ? "active" : ""); ?>"><a href="<?php echo e(url("about")); ?>"><?php echo app('translator')->getFromJson("global.menu.about_us_label"); ?></a></li>
              
              <li class="<?php echo e(($data['menu'] == "specialist") ? "active" : ""); ?>"><a href="<?php echo e(route("specialist")); ?>"><?php echo app('translator')->getFromJson("global.menu.specialist_label"); ?></a></li>
              
              <li class="dropdown <?php echo e(($data['menu'] == "news" || $data['menu'] == "gallery") ? "active" : ""); ?>">
                  <a href="#." class="dropdown-toggle" data-toggle="dropdown"><?php echo app('translator')->getFromJson("global.menu.what_up_label"); ?></a>
                  <ul class="dropdown-menu">
                    <li class="dropdown">
                      <a href="<?php echo e(route("news")); ?>"><?php echo app('translator')->getFromJson("global.menu.news_label"); ?></a>
                      <a href="<?php echo e(route("gallery")); ?>"><?php echo app('translator')->getFromJson("global.menu.gallery_label"); ?></a>
                    </li>
                  </ul>
              </li>
              <li class="<?php echo e(($data['menu'] == "contact") ? "active" : ""); ?>"><a href="<?php echo e(route("contact_us")); ?>"><?php echo app('translator')->getFromJson("global.menu.contact_us"); ?></a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle language-header" data-toggle="dropdown" href="" aria-expanded="false"><?php echo e((app()->getLocale() == 'id') ? "ID" : "EN"); ?>

                    <ul class="dropdown-menu">
                      <li><a class="current" href="<?php echo e(\Route::currentUrl('id')); ?>">ID</a></li>
                      <li><a class="" href="<?php echo e(\Route::currentUrl('en')); ?>">EN</a></li>
                    </ul>
                </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </nav>
</header>
<!--Header Ends-->


<?php echo $__env->yieldContent('content'); ?>

<!--Footer-->
<footer class="footer_third">
  <div class="container contacts">
    <div class="row">
      <div class="col-sm-4 text-center">
        <div class="info-box first">
          <div class="icons"><i class="icon-telephone114"></i></div>
          <ul class="text-center">
            <li><strong><?php echo app('translator')->getFromJson("global.phone_label"); ?></strong></li>
            <li><?php echo e($profile->phone); ?></li>
          </ul>
        </div>
      </div>
      <div class="col-sm-4 text-center">
        <div class="info-box">
          <div class="icons"><i class="icon-icons74"></i></div>
          <ul class="text-center">
            <li><strong>Address</strong></li>
            <li><?php echo e($profile->address); ?></li>
          </ul>
        </div>
      </div>
      <div class="col-sm-4 text-center">
        <div class="info-box">
          <div class="icons"><i class="icon-icons142"></i></div>
          <ul class="text-center">
            <li><strong><?php echo app('translator')->getFromJson("global.email_label"); ?></strong></li>
            <li><a href="#."><?php echo e($profile->email); ?></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="container padding_top">
    <div class="row">
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
        <a href="<?php echo e(route('home')); ?>" class="logo bottom30"><img src="<?php echo e($config->LogoPath); ?>" alt="logo" style="height: 80px;"></a>
          <p class="bottom15"><?php echo e($profile->tag_line); ?>

          </p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          <h4 class="bottom30 heading">Menu</h4>
          <table style="width:100%;">
            <tbody>
              <tr>
                <td>
                  <ul class="links">
                    <li><a href="<?php echo e(route('home')); ?>"><i></i><?php echo app('translator')->getFromJson('global.menu.home_label'); ?></a></li>
                    <li><a href="<?php echo e(route('about')); ?>"><i></i><?php echo app('translator')->getFromJson('global.menu.about_us_label'); ?></a></li>
                    <li><a href="<?php echo e(route('news')); ?>"><i></i><?php echo app('translator')->getFromJson('global.menu.news_label'); ?></a></li>
                   
                  </ul>
                </td>
                <td class="text-right">
                  <ul class="links text-left">
                      <li><a href="<?php echo e(route('gallery')); ?>"><i></i><?php echo app('translator')->getFromJson('global.menu.gallery_label'); ?></a></li>
                      <li><a href="<?php echo e(route('specialist')); ?>"><i></i><?php echo app('translator')->getFromJson('global.menu.specialist_label'); ?></a></li>
                      <li><a href="<?php echo e(route('contact_us')); ?>"><i></i><?php echo app('translator')->getFromJson('global.menu.contact_us'); ?></a></li>
                  </ul>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          <h4 class="bottom30 heading"><?php echo app('translator')->getFromJson("global.latest_news_label"); ?></h4>
          
          <?php $__currentLoopData = $newsFooter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo $__env->make('user/items/thumb_news_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel bottom30">
          
        </div>
      </div>
    </div>
    <!--CopyRight-->
    <div class="copyright_simple">
      <div class="row">
        <div class="col-md-6 col-sm-5 top20 bottom20">
          <p>Copyright &copy; 2019 <span><?php echo e($config->name); ?></span>. All rights reserved.</p>
        </div>
        <div class="col-md-6 col-sm-7 text-right top15 bottom10">
          <ul class="social_share">
            <li><a href="<?php echo e($profile->facebook); ?>" class="facebook"><i class="icon-facebook-1"></i></a></li>
            <li><a href="<?php echo e($profile->instagram); ?>" class="instagram"><i class="icon-instagram"></i></a></li>
            <li><a href="mailto:<?php echo e($profile->email); ?>" class="google"><i class="icon-google4"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>



<script src="<?php echo e(url('public/assets/user')); ?>/js/bootstrap.min.js"></script> 
<script src="<?php echo e(url('public/assets/user')); ?>/js/jquery.appear.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/jquery-countTo.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/bootsnav.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/masonry.pkgd.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/jquery.parallax-1.1.3.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/jquery.cubeportfolio.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/range-Slider.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/owl.carousel.min.js"></script> 
<script src="<?php echo e(url('public/assets/user')); ?>/js/selectbox-0.2.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/zelect.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/jquery.fancybox.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/jquery.themepunch.tools.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/jquery.themepunch.revolution.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/revolution.extension.actions.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/revolution.extension.layeranimation.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/revolution.extension.navigation.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/revolution.extension.parallax.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/revolution.extension.slideanims.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/revolution.extension.video.min.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/custom.js"></script>
<script src="<?php echo e(url('public/assets/user')); ?>/js/functions.js"></script>

<script src="<?php echo e(url('public/assets/user')); ?>/js/neary-by-place.js"></script> 
<script src="<?php echo e(url('public/assets/user')); ?>/js/contact.js"></script>



</body>
</html>

<?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/template.blade.php ENDPATH**/ ?>