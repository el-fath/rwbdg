<div class="cbp-item">
    <a href="#">
        <img src="<?php echo e($item->ImagePathSmall); ?>" alt="<?php echo e($item->title); ?>" class="img-responsive" style="height: 260px;">
        <div class="grid-caption">
        <h3><?php echo e($item->title); ?></h3>
        <span><?php echo e($item->CountProperty); ?> Properties</span>
        </div>
    </a>
</div><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/items/thumb_category_property_home.blade.php ENDPATH**/ ?>