<?php $__env->startSection('title'); ?>
<?php echo e($data['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">

    <!-- Page header -->
    <div class="page-header page-header-light">
        <div class="page-header-content header-elements-md-inline">
            <div class="page-title d-flex">
                <h4><i class="icon-arrow-left52 mr-2"></i> <span class="font-weight-semibold">Home</span> - <?php echo e($data['title']); ?>

                </h4>
                <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
            </div>
        </div>

        <div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Home</a>
                    <span class="breadcrumb-item active"><?php echo e($data['title']); ?></span>
                </div>

                <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
            </div>
        </div>
    </div>
    <!-- /page header -->

    <!-- Content area -->
    <div class="content">

        <?php if(session('alert')): ?>
        <!-- alert -->
        <div class="alert alert-success alert-styled-left alert-arrow-left alert-dismissible">
            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
            <span class="font-weight-semibold">Well done! </span><?php echo e(session('alert')); ?>

        </div>
        <!-- alert -->
        <?php endif; ?>
    

        <div class="content">

            <!-- Basic datatable -->
        <div class="card">
            <div class="card-header header-elements-inline">
                <h5 class="card-title">Master <?php echo e($data['title']); ?></h5>
                
                <div class="header-elements">
                    <div class="list-icons">
                        <a class="list-icons-item" data-action="reload"></a>
                        <a class="list-icons-item" data-action="collapse"></a>
                        
                    </div>
                </div>
            </div>
            <div class="card-body">
                <a href="<?php echo e(url('admin/property/create')); ?>"><button type="button" class="btn bg-teal-400 btn-labeled btn-labeled-left"><b><i class="icon-plus-circle2"></i></b> Add <?php echo e($data['title']); ?></button></a>
            </div>
            <table class="table datatable-basic" id="tableData">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Slug</th>
                        <th>Desc</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    
                    <tr>
                        <td><?php echo e($no); ?></td>
                        <td>
                            <img src="<?php echo e($val->ImagePathSmall); ?>" alt="" style="width:120px;">
                        </td>
                        <td><a href="#"><?php echo e($val->{'title:id'}); ?></a></td>
                        <td><?php echo e($val->{'slug:id'}); ?></td>
                        <td><?php echo str_limit(strip_tags($val->{'description:id'}), 150); ?>...</td>
                        <td class="text-center">
                            <div class="list-icons">
                                <div class="dropdown">
                                    <a href="#" class="list-icons-item" data-toggle="dropdown">
                                        <i class="icon-menu9"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a href="<?php echo e(route('admin.property.edit', $val->id)); ?>" class="dropdown-item">
                                            <i class="icon-pencil7"></i> Edit
                                        </a>
                                        <a href="<?php echo e(route('admin.property.destroy', $val->id)); ?>" data-id="<?php echo e($val->id); ?>" class="dropdown-item btnDelete">
                                            <i class="icon-trash"></i> Delete
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php $no++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /basic datatable -->
        </div>
    </div>
</div>
<script>
$(document).ready( function () {
    $('#table').DataTable();
});

$(".btnDelete").click(function(e){
    e.preventDefault();
    var objBtn = $(this);
    swal({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!',
        confirmButtonClass: 'btn btn-success',
        cancelButtonClass: 'btn btn-danger',
        buttonsStyling: false
    }).then(function(result) {
        if(result.value) {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type: "POST",
                url: objBtn.attr("href"),
                data: {
                    id:objBtn.attr("data-id"),
                    _method: 'DELETE'
                },
                beforeSend: function(){
                    blockMessage($('#tableData'),'Please Wait , <?php echo e("Processing to delete data"); ?>','#fff');
                }
                }).done(function(data){
                    $('#tableData').unblock();
                    if(data.Code == 200){
                        showNotif("success","Success",data.Message);
                    }else{
                        showNotif("error","Error",data.Message);
                    }
                    setTimeout(function(){ 
                        redirect('<?php echo e(route('admin.property.index')); ?>');
                    }, 1500);
                })
                .fail(function(e) {
                    $('#tableData').unblock();
                    showNotif("error","Error",e.responseText);
                });
        }
        else if(result.dismiss === swal.DismissReason.cancel) {
            showNotif("default","Message","Delete Canceled");
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/admin/property/index.blade.php ENDPATH**/ ?>