<?php $__env->startSection('content'); ?>

<!-- Property Detail Start -->
<section id="property" class="padding">
  <div class="container property-details">
    <div class="row">
        <div class="col-md-12">
           <h2 class="text-uppercase"><?php echo e($data['data']->title); ?></h2>
           <p class="bottom30"><?php echo e($data['data']->address); ?></p>
           <div id="property-d-1" class="owl-carousel single">
              <div class="item"><img src="<?php echo e($data['data']->ImagePath); ?>" alt="image"/></div>
           </div>
           
           <div class="property_meta bg-black bottom40">
            <span><i class="icon-select-an-objecto-tool"></i><?php echo e($data['data']->land_area); ?>

               m<sup>2</sup></span>
           <span><i class="icon-old-television"></i><?php echo e($data['data']->building_area); ?>

               m<sup>2</sup></span>
           <span><i
                   class=" icon-microphone"></i><?php echo e($data['data']->bedroom); ?>+<?php echo e($data['data']->extra_bedroom); ?>

               Office Rooms</span>
           <span><i
                   class="icon-safety-shower"></i><?php echo e($data['data']->bathroom); ?>+<?php echo e($data['data']->extra_bedroom); ?>

               Bathroom</span>
           </div>
        </div>
        <div class="col-md-8">
          <h2 class="text-uppercase"><?php echo app('translator')->getFromJson('property.prop_desc'); ?></h2>
          <p class="bottom30">
            <?php echo $data['data']->description; ?>

          </p>
          <hr>
          <br>
          <h2 class="text-uppercase bottom20"><?php echo app('translator')->getFromJson('property.quick_summary_label'); ?></h2>
            <div class="row property-d-table bottom40">
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <table class="table table-striped table-responsive">
                        <tbody>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.property_id'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->id); ?></td>
                              </tr>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.price'); ?></b></td>
                                 <?php if($data['data']->type_transaction == 'sale'): ?>
                                 <td class="text-right">Rp.
                                    <?php echo e(number_format($data['data']->sale_price,0,",",".")); ?></td>
                                 <?php else: ?>
                                 <td class="text-right">Rp.
                                    <?php echo e(number_format($data['data']->rent_price,0,",",".")); ?></td>
                                 <?php endif; ?>
                              </tr>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.land_area'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->land_area); ?> m<sup>2</sup></td>
                              </tr>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.building_area'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->building_area); ?> m<sup>2</sup></td>
                              </tr>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.bedrooms'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->bedroom); ?> +
                                    <?php echo e($data['data']->extra_bedroom); ?></td>
                              </tr>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.bathrooms'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->bathroom); ?> +
                                    <?php echo e($data['data']->extra_bathroom); ?></td>
                              </tr>

                        </tbody>
                     </table>
                  </div>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <table class="table table-striped table-responsive">
                        <tbody>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.type'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->type_transaction); ?></td>
                              </tr>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.available_from'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->created_at->format('M d,Y')); ?></td>
                              </tr>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.certificate'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->certificate); ?></td>
                              </tr>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.category'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->category->title); ?></td>
                              </tr>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.floors'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->floor); ?></td>
                              </tr>
                              <tr>
                                 <td><b><?php echo app('translator')->getFromJson('property.summary.electricity'); ?></b></td>
                                 <td class="text-right"><?php echo e($data['data']->electricity); ?></td>
                              </tr>
                        </tbody>
                     </table>
                  </div>
            </div>
          <br>
          <hr>
          <h2 class="text-uppercase bottom20">Marketplace</h2>
            <div class="row property-d-table bottom40">
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <?php $__currentLoopData = $data['data']->marketplaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="media">
                              <div class="media-left">
                              <a href="#">
                                    <img class="media-object" style="width: 64px;height: 64px;object-fit: cover;" src="<?php echo e($item->marketplace->ImagePathSmall); ?>" alt="<?php echo e($item->marketplace->title); ?>">
                              </a>
                              </div>
                              <div class="media-body" style="vertical-align: middle;">
                              <h4 class="media-heading"><?php echo e($item->marketplace->title); ?></h4>
                              <a href="<?php echo e($item->url); ?>" target="_blank"><?php echo e($item->url); ?></a>
                              </div>
                        </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
            </div>
        </div>
        <div class="col-md-4">
            <h2 class="text-uppercase bottom20"><?php echo app('translator')->getFromJson('property.prop_owner'); ?></h2>
            <div class="row">
               <div class="col-sm-4 bottom40">
                  <div class="agent_wrap">
                     <div class="image">
                        <img src="<?php echo e($data['data']->marketing['ImagePathMedium']); ?>" alt="Agents">
                     </div>
                  </div>
               </div>
               <div class="col-sm-8 bottom40">
                  <div class="agent_wrap">
                     <h3><?php echo e($data['data']->marketing['name']); ?></h3>
                     <p class="bottom30"><?php echo e($data['data']->marketing['description']); ?></p>
                  </div>
               </div>
               <div class="col-sm-12 agent_wrap bottom30">
                  <table class="agent_contact table">
                     <tbody>
                        <tr class="bottom10">
                           <td><strong><?php echo app('translator')->getFromJson('specialist.phone'); ?>:</strong></td>
                           <td class="text-right"><?php echo e($data['data']->marketing['phone']); ?></td>
                        </tr>
                        <tr>
                           <td><strong><?php echo app('translator')->getFromJson('specialist.email'); ?>:</strong></td>
                           <td class="text-right"><?php echo e($data['data']->marketing['email']); ?></td>
                        </tr>
                        <tr>
                           <td><strong>Instagram:</strong></td>
                           <td class="text-right"><?php echo e($data['data']->marketing['instagram']); ?></td>
                        </tr>
                        <tr>
                          <td><strong>Facebook:</strong></td>
                          <td class="text-right"><?php echo e($data['data']->marketing['facebook']); ?></td>
                       </tr>
                     </tbody>
                  </table>
                  
               </div>
               
            </div>
            
        </div>
    </div>
  </div>
</section>
<!-- Property Detail End -->
  
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('user/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/property/detail.blade.php ENDPATH**/ ?>