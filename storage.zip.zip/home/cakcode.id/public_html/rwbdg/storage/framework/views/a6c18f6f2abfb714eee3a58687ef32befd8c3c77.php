<?php $__env->startSection('content'); ?>
<!--About Us -->
<section id="about" class="padding_bottom">
    
  <section class="page-banner padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <h1 class="text-uppercase"><?php echo app('translator')->getFromJson('about.about_us'); ?></h1>
          
          <p>
            <?php echo e($profile->tag_line); ?>

          </p>
          <ol class="breadcrumb text-center">
            <li><a href="#">Home</a></li>
            <li><a href="#"><?php echo app('translator')->getFromJson('about.page'); ?></a></li>
            <li class="active"><?php echo app('translator')->getFromJson('about.about'); ?></li>
          </ol> --}}
        </div>
      </div>
    </div>
  </section>
  <section id="faqs" class="padding_half bottom40">
  <img src="<?php echo e($config->LogoPath); ?>" style="width: 250px; margin:auto; display:block" class="logo" alt=""><br>
  <div class="container" align="center">
    <ul class="social_share bottom20">
      <li><a href="https://www.facebook.com/<?php echo e($profile->social_facebook); ?>" target="_blank"
        title="https://www.facebook.com/<?php echo e($profile->social_facebook); ?>" class="facebook">
        <i class="icon-facebook-1"></i></a>
      </li>
      <li><a href="https://www.twitter.com/<?php echo e($profile->social_twitter); ?>" target="_blank"
        title="https://www.twitter.com/<?php echo e($profile->social_twitter); ?>" class="twitter">
        <i class="icon-twitter-1"></i></a>
      </li>
      <li><a href="https://www.instagram.com/<?php echo e($profile->social_twitter); ?>" target="_blank"
        title="https://www.instagram.com/<?php echo e($profile->social_twitter); ?>" class="google">
        <i class="icon-instagram"></i></a>
      </li>
    </ul>
  </div>
  <br>
  <div class="container">
      <div class="row">
        <div align="justify" class="col-sm-12">
          <h1>
            <?php echo e($profile->name); ?>

          </h1>
          <br>
          <p>
            <?php echo $profile->description; ?>

          </p>
        </div>
      </div>
    </div>
  </section>
  
</section>
  
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('user/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/about.blade.php ENDPATH**/ ?>