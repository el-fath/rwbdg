<?php $__env->startSection('content'); ?>
<!-- News Start -->
<section id="news-section-1" class="property-details padding_top">
    <div class="container property-details">
        <h1>News</h1>
        <br>
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                <?php $__currentLoopData = $data['news']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('user/items/thumb_news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($data['news']->links("user/include/pagination")); ?>

                </div>
            </div>
            <aside class="col-md-4 col-xs-12">
                <div class="row">
                <div class="col-md-12">
                    <form class="form-search bottom40" method="get" id="news-search" action="<?php echo e(route("news")); ?>">
                        <div class="input-append">
                            <input type="text" class="input-medium search-query" name="search" placeholder="Search Here" value="">
                            <button type="submit" class="add-on"><i class="icon-icons185"></i></button>
                        </div>
                    </form>
                </div>
                <div class="col-md-12">
                    <h3 class="bottom20">Categories</h3>
                    <ul class="pro-list bottom20">
                        <?php $__currentLoopData = $data['news_category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <li>
                           <a href="<?php echo e(route('news', ['category'=>$item->id])); ?>">  <?php echo e($item->title); ?></a>
                        </li>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </ul>
                </div>
                </div>
            </aside>
        </div>
    </div>
</section>
<!-- News End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/news.blade.php ENDPATH**/ ?>