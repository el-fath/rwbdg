<?php $__env->startSection('content'); ?>
<!-- Listing Start -->
<section id="listing1" class="listing1 padding_top">
    <div class="container">
        <div class="row">
        <div class="col-md-8 col-sm-12 col-xs-12">
            <div class="row">
            <div class="col-md-9">
                <h2 class="uppercase"><?php echo app('translator')->getFromJson('property.property_listing_label'); ?></h2>
                <p class="heading_space"><?php echo app('translator')->getFromJson('property.property_listing_desc_label'); ?></p>
            </div>
            <div class="col-md-3">
            <form class="callus">
                <div class="single-query">
                <div class="intro">
                    <select>
                        <option class="active"><?php echo app('translator')->getFromJson('property.sort_label'); ?></option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                        <option>6</option>
                    </select>
                </div>
                </div>
                </form>
            </div>
            </div>
            <div class="row">
            <?php $__currentLoopData = $data['property_latest']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6">
                    
                        <?php echo $__env->make('user/items/thumb_property', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div class="padding_bottom text-center">
            <ul class="pager">
                <li><a href="#">1</a></li>
                <li class="active"><a href="#">2</a></li>
                <li><a href="#">3</a></li>
            </ul>
            </div>
        </div>
        <?php echo $__env->make('user/include/property_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</section>
<!-- Listing end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/property.blade.php ENDPATH**/ ?>