<?php $__env->startSection('search'); ?>
<button type="button" class="form_opener"><i class="fa fa-bars"></i></button>
<div class="tp_overlay">
  
  
  <form class="callus top30 clearfix centered">
    <h2 class="text-uppercase t_white bottom20 text-center"><?php echo app('translator')->getFromJson("home.advance_search.title"); ?></h2>
    <div class="row">
      <div class="col-sm-6">
        <div class="single-query bottom15">
          <input type="text" class="keyword-input" placeholder="<?php echo app('translator')->getFromJson("home.advance_search.keyword_field"); ?>">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="single-query bottom15">
          <div class="intro">
            <select>
              <option selected="" value="any"><?php echo app('translator')->getFromJson("home.advance_search.property_transaction"); ?></option>
              <?php $__currentLoopData = $data['property_transaction']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="single-query bottom15">
          <div class="intro">
            <select>
              <option class="active"><?php echo app('translator')->getFromJson("home.advance_search.property_category_field"); ?></option>
              
              <?php $__currentLoopData = $data['property_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="single-query bottom15">
          <div class="intro">
            <select>
              <option class="active"><?php echo app('translator')->getFromJson("home.advance_search.property_type_field"); ?></option>
              <?php $__currentLoopData = $data['property_type']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
      </div>
      <div class="search-2">
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="single-query bottom15">
            <div class="intro">
              <select>
                <option class="active"><?php echo app('translator')->getFromJson("home.advance_search.min_bed_field"); ?></option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="single-query bottom15">
            <div class="intro">
              <select>
                <option class="active"><?php echo app('translator')->getFromJson("home.advance_search.min_bath_field"); ?></option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-6">
        <div class="single-query bottom15">
          <input type="text" class="keyword-input" placeholder="<?php echo app('translator')->getFromJson("home.advance_search.min_landarea_field"); ?>">
        </div>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-6">
        <div class="single-query bottom15">
          <input type="text" class="keyword-input" placeholder="<?php echo app('translator')->getFromJson("home.advance_search.min_buldingarea_field"); ?>">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 col-sm-8 col-xs-8 bottom15">
        <div class="single-query-slider">
          <div class="clearfix top20">
            <label class="pull-left"><?php echo app('translator')->getFromJson("home.advance_search.price_range_field"); ?>:</label>
            <div class="price text-right">
              <span>Rp</span>
              <div class="leftLabel"></div>
              <span>to Rp</span>
              <div class="rightLabel"></div>
            </div>
          </div>
          <div data-range_min="0" data-range_max="1000000000000" data-cur_min="0" data-cur_max="0" class="nstSlider">
            <div class="bar"></div>
            <div class="leftGrip"></div>
            <div class="rightGrip"></div>
          </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-4 text-right form-group top30">
        <button type="submit" class="border_radius btn-yellow text-uppercase"><?php echo app('translator')->getFromJson("home.advance_search.search_btn"); ?></button>
      </div>
    </div>
    
  </form>
</div>
<?php $__env->stopSection(); ?><?php /**PATH /home/cakcode.id/public_html/rwbdg/resources/views/user/include/search.blade.php ENDPATH**/ ?>